﻿namespace Autenticacao.Config
{
    public class Configuracoes
    {
        public static string Secret = "fedaf7d8863b48e197b9287d492b708e";
    }
}
