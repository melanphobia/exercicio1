async function cadastrar()
    {
        let auxU = document.getElementById("name_login").value
        let auxS = document.getElementById("senha_login").value
        let cargo = document.getElementsByName('cargo_login').value
        let resultado = document.querySelector("#resultados")
        let auxR = ""
        if (cargo[0].checked == true){
            auxR = "admin"
        }
        else if (cargo[1].checked == true){
            auxR = "gerente"
        }
        else if (cargo[2].checked == true){
            auxR = "funcionario"
        }
        let obj = 
        {
            username: auxU,
            password: auxS,
            role: auxR
        }
        if(auxU != "" && auxS !="" && auxR != "")
        {
            await  fech('http://localhost:5063/api/Users',
            {
                method: "POST",
                headers: {'Authorization': 'Bearer ' + token,'Content-Type' : 'application/json'},
                body: JSON.stringify(obj)
            })

        }
    }
async function cadastrarproduto(){
    let auxA = document.getElementById("descricao").value
    let auxS = document.getElementById("preco").value
    let auxD = document.getElementById("estoque").value
    let auxF = document.getElementById("categoria").value

    let obj = 
    {
        descricao: auxA,
        preco: auxS,
        estoque: auxD,
        categoria: auxF
    }
    if(auxA != "" && auxS !="" && auxD != "" && auxF != "")
    {
        await fetch('http://localhost:5063/api/Produtos',
        {
            method: "POST",
            headers: {'Authorization': 'Bearer ' + token,'Content-Type' : 'application/json'},
            body: JSON.stringify(obj)
        })

    }
}


function carregar() {
    
    produto = ''
    tabela = document.getElementsByTagName("tbody")[0]
    tabela.innerHTML = ''
    fetch('http://localhost:5063/api/Produtos')
    .then(data => {
        return data.json();
    })
    .then(post => {
        post.forEach(element => {
            produto = `<tr>
                <td>${element.id}</td>
                <td>${element.descricao}</td>
                <td>${element.estoque}</td>
                <td>${element.preco}</td>
                <td>${JSON.stringify(element.categoria)}</td>
                </tr>`
            tabela.innerHTML += produto
        });
    });   
    let table = document.getElementById("tabela")
    table.removeAttribute("hidden")
    console.log(produto)
}

async function cadastrarcategoria(){
    
    let auxS = document.getElementById("nome").value

    let obj = 
    {
        nome: auxS
      
    }
    if(auxS !="")
    {
        await fetch('http://localhost:5063/api/Categorias',
        {
            method: "POST",
            headers: {'Authorization': 'Bearer ' + token,'Content-Type' : 'application/json'},
            body: JSON.stringify(obj)
        })

    }
}
async function Logar()
    {
        let resultado = document.querySelector("#resultados")
        let auxU = document.getElementById("name_login").value
        let auxS = document.getElementById("senha_login").value
        let obj = 
        {
            username: auxU,
            password: auxS
        }
        if(auxU != "" && auxS != "")
        {
            fetch('http://localhost:5063/api/Users',
            {
                method: "POST",
                headers: {'Content-Type' : 'application/json'},
                body: JSON.stringify(obj)
            })
            .then(data => data.json())
            .then(resp => {
                localStorage.setItem('token', resp.token)
            })
        }
        if(localStorage.getItem("token") === null){
        resultado.innerHTML = "Login realizado com sucesso!"
    }
    }